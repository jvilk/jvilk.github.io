
import React from 'react';

export default class Counter extends React.Component {
  getDefaultProps() {
    return { title: 'Basic counter!!!', step: 1 }
  }

  getInitialState() {
    return {count: (this.props.initialCount || 0)}
  }

  render() {
    let step = this.props.step;
    return (
      <div>
        <h1>{this.props.title}</h1>
        <div>{this.state.count}</div>
        <input type='button' value='+'
               onClick={() => this.updateCounter(step)}/>
        <input type='button' value='-'
               onClick={() => this.updateCounter(-step)}/>
      </div>
    );
  }

  updateCounter(amount) {
    let newCount = this.state.count + amount;
    this.setState({ count : newCount });
  }
}
