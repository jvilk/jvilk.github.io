import React from 'react';
import ReactDOM from 'react-dom';
import Counter from './components/Counter';


class App extends React.Component {
  render() {
    return (
      <Counter initialCount={5} step={2} />
    );
  }
}

ReactDOM.render(<App/>, document.getElementById('app'));
