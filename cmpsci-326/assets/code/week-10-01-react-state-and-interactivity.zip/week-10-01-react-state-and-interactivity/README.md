# Workshop3Solution
Contains the solution to workshop 3.
