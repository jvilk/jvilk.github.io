import React from 'react';
import Markdown from 'react-remarkable';

export default class MarkdownEditor extends React.Component {
  constructor(props) {
    super(props);
    this.state = {value: 'Type some *markdown* here!'};
  }

  handleChange() {
    this.setState({value: this.refs.textarea.value});
  }

  render() {
    return (
      <div className="MarkdownEditor">
        <h3>Input</h3>
        <textarea
          onChange={() => this.handleChange()}
          cols="100"
          ref="textarea"
          defaultValue={this.state.value} />
        <h3>Output</h3>
        <Markdown source={this.state.value}/>
      </div>
    );
  }
}
