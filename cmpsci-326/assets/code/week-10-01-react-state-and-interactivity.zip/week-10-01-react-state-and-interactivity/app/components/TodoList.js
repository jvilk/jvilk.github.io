import React from 'react';

export default class TodoApp extends React.Component {
  constructor(props) {
    super(props);
    this.state = {items: [], text: ''};
  }

  render() {
    return (
      <div>
        <h3>TODO / {this.state.text}</h3>
        <TodoList items={this.state.items} />
        <form onSubmit={(e) => this.handleSubmit(e)} className="input-group">
          <input onChange={(e) => this.handleChange(e)}
            className="form-control" value={this.state.text} />
          <span className="input-group-btn">
            <button className="btn btn-default">
              {'Add #' + (this.state.items.length + 1)}
            </button>
        </span>
        </form>
      </div>
    );
  }

  handleChange(e) {
    this.setState({text: e.target.value});
  }

  handleSubmit(e) {
    e.preventDefault();
    var newItem = {
      text: this.state.text,
      id: Date.now()
    };
    this.setState((prevState) => ({
      items: prevState.items.concat(newItem),
      text: ''
    }));
  }
}

class TodoList extends React.Component {
  render() {
    return (
      <ul>
        {this.props.items.map(item => (
          <li key={item.id}>{item.text}</li>
        ))}
      </ul>
    );
  }
}
