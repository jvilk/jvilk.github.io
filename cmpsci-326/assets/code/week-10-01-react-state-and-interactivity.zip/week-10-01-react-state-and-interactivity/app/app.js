import React from 'react';
import ReactDOM from 'react-dom';
import Timer from './components/Timer';
import TodoList from './components/ToDoList';
import MarkdownEditor from './components/MarkdownEditor';

class App extends React.Component {
  render() {
    return (
      <div>
        <Timer/>
        <TodoList />
        <MarkdownEditor />
      </div>
    );
  }
}

ReactDOM.render(<App/>, document.getElementById('app'));
